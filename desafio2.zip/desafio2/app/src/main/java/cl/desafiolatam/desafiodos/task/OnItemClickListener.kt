package cl.desafiolatam.desafiodos.task

interface OnItemClickListener {
    fun onItemClick(taskItem:TaskUIDataHolder)
}