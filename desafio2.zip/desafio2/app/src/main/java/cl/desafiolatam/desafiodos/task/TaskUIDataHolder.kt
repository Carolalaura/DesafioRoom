package cl.desafiolatam.desafiodos.task

data class TaskUIDataHolder (
    var id:Long,
    var text:String
)